--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Blog_Technology";
--
-- Name: Blog_Technology; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Blog_Technology" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Blog_Technology" OWNER TO postgres;

\connect "Blog_Technology"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CategoryPost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CategoryPost" (
    "categoryId" integer NOT NULL,
    "categoryName" character varying
);


ALTER TABLE public."CategoryPost" OWNER TO postgres;

--
-- Name: Comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Comment" (
    "commentId" integer NOT NULL,
    "postId" integer,
    "userId" integer,
    "contentComment" character varying
);


ALTER TABLE public."Comment" OWNER TO postgres;

--
-- Name: Post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Post" (
    "postId" integer NOT NULL,
    "postName" character varying,
    content character varying,
    photo character varying,
    "userId" integer,
    "categoryId" integer
);


ALTER TABLE public."Post" OWNER TO postgres;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    "userId" integer NOT NULL,
    "userName" character varying,
    phone character varying,
    password character varying
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: User_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Users" ALTER COLUMN "userId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."User_userid_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: baiviet_mabaiviet_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Post" ALTER COLUMN "postId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.baiviet_mabaiviet_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: danhgia_madanhgia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Comment" ALTER COLUMN "commentId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.danhgia_madanhgia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: loaibaiviet_maloai_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."CategoryPost" ALTER COLUMN "categoryId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.loaibaiviet_maloai_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: CategoryPost; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CategoryPost" ("categoryId", "categoryName") FROM stdin;
\.
COPY public."CategoryPost" ("categoryId", "categoryName") FROM '$$PATH$$/4863.dat';

--
-- Data for Name: Comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Comment" ("commentId", "postId", "userId", "contentComment") FROM stdin;
\.
COPY public."Comment" ("commentId", "postId", "userId", "contentComment") FROM '$$PATH$$/4865.dat';

--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Post" ("postId", "postName", content, photo, "userId", "categoryId") FROM stdin;
\.
COPY public."Post" ("postId", "postName", content, photo, "userId", "categoryId") FROM '$$PATH$$/4867.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" ("userId", "userName", phone, password) FROM stdin;
\.
COPY public."Users" ("userId", "userName", phone, password) FROM '$$PATH$$/4861.dat';

--
-- Name: User_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_userid_seq"', 6, true);


--
-- Name: baiviet_mabaiviet_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.baiviet_mabaiviet_seq', 1, false);


--
-- Name: danhgia_madanhgia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.danhgia_madanhgia_seq', 1, false);


--
-- Name: loaibaiviet_maloai_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loaibaiviet_maloai_seq', 1, false);


--
-- Name: Post baiviet_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT baiviet_pk PRIMARY KEY ("postId");


--
-- Name: Comment danhgia_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT danhgia_pk PRIMARY KEY ("commentId");


--
-- Name: CategoryPost loaibaiviet_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CategoryPost"
    ADD CONSTRAINT loaibaiviet_pk PRIMARY KEY ("categoryId");


--
-- Name: Users user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT user_pk PRIMARY KEY ("userId");


--
-- Name: Users users_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT users_unique UNIQUE ("userName");


--
-- Name: Post baiviet_loaibaiviet_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT baiviet_loaibaiviet_fk FOREIGN KEY ("categoryId") REFERENCES public."CategoryPost"("categoryId");


--
-- Name: Post baiviet_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT baiviet_user_fk FOREIGN KEY ("userId") REFERENCES public."Users"("userId");


--
-- Name: Comment danhgia_baiviet_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT danhgia_baiviet_fk FOREIGN KEY ("postId") REFERENCES public."Post"("postId");


--
-- Name: Comment danhgia_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT danhgia_user_fk FOREIGN KEY ("userId") REFERENCES public."Users"("userId");


--
-- PostgreSQL database dump complete
--

